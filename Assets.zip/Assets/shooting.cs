using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class shooting : MonoBehaviour
{
    public Transform firepoint;
    public GameObject Bullet1Prefab;
    public float Bullet1force = 50f;
    // Start is called before the first frame update
    void Start()
    {
    }
    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            shoot();
        }
    }
    void shoot()
    {
        //Debug.Log(Firepoint.position);
        GameObject Bullet = Instantiate(Bullet1Prefab, firepoint.position, firepoint.rotation);
        Rigidbody2D rb = Bullet.GetComponent<Rigidbody2D>();
        rb.AddForce(firepoint.right * Bullet1force, ForceMode2D.Impulse);
    }
}
